import { AppError } from "../../../shared/utils/AppError.js";
import { env } from "../../../shared/utils/env.js";
import { decideImportEligibility } from "../../timesheets/repository/timesheetImport.repository.js";
import { parseTimesheetWorkbook, validateAttachment } from "../../timesheets/services/excelParser.service.js";
import { processTimesheetImport } from "../../timesheets/services/timesheet.service.js";
import {
  notifyKekaImportFailedBeforeImportRow,
  notifyTimesheetImportOutcome,
} from "../../timesheets/services/timesheetImportNotification.service.js";
import { getGraphAccessToken, isGraphConfigured } from "./graphAuth.service.js";
import type { GraphAttachment, GraphMessage, PollResult } from "../mailIngestion.types.js";

/**
 * Mailbox polling — server-side only, no dependency on any user's browser
 * or PC being on. Calls the exact same processTimesheetImport() engine as
 * the Administrator manual-upload path (see timesheet.controller.ts); the
 * only difference is the `triggeredBy: "EmailPoll"` metadata and the real
 * emailMessageId/attachmentId this function fills in from Graph.
 *
 * NOT YET VERIFIED against a real KEKA mailbox — see graphAuth.service.ts's
 * own note. This function has been exercised only for its control flow
 * (unconfigured-Graph short-circuit); it has never successfully called the
 * real Microsoft Graph API, since no tenant credentials exist in this
 * environment yet.
 */

const GRAPH_BASE = "https://graph.microsoft.com/v1.0";

async function graphFetch<T>(path: string, token: string): Promise<T> {
  const response = await fetch(`${GRAPH_BASE}${path}`, {
    headers: { Authorization: `Bearer ${token}` },
  });

  if (!response.ok) {
    const body = await response.text().catch(() => "");
    throw new Error(`Graph request failed (${response.status} ${response.statusText}): ${body.slice(0, 500)}`);
  }

  return response.json() as Promise<T>;
}

/**
 * Finds candidate KEKA emails within a lookback window (Decision 9 — never
 * just "today"), decides per-email whether to process/retry/skip via
 * decideImportEligibility() (emailMessageId is unique — this IS the
 * duplicate-email guard, a different concern from the row-level
 * reconciliation inside processTimesheetImport), downloads the matching
 * attachment, and hands it to the shared engine. One message failing (a
 * parse error, a missing attachment, a transient Graph error) never stops
 * the rest of the batch — Stage 4 §16 step 9.
 *
 * P2-08 — a message whose only prior TimesheetImport is "Failed" is no
 * longer treated as permanently done: it is retried (reusing that same
 * row) rather than silently skipped forever. See
 * timesheetImport.repository.ts's decideImportEligibility() for the full
 * per-status decision and its atomic, race-safe retry claim.
 */
export async function pollKekaMailbox(): Promise<PollResult> {
  if (!isGraphConfigured()) {
    throw new AppError(
      "Microsoft Graph is not configured — set MICROSOFT_TENANT_ID/MICROSOFT_CLIENT_ID/MICROSOFT_CLIENT_SECRET/KEKA_MAILBOX/KEKA_SENDER_EMAIL/KEKA_ATTACHMENT_NAME in Backend/.env.",
      503
    );
  }

  const result: PollResult = {
    messagesFound: 0,
    processed: 0,
    skippedAlreadyProcessed: 0,
    skippedNoAttachment: 0,
    errors: [],
    createdCount: 0,
    updatedCount: 0,
    unchangedCount: 0,
    removedCount: 0,
    failedCount: 0,
  };

  const token = await getGraphAccessToken();

  const lookbackDate = new Date();
  lookbackDate.setDate(lookbackDate.getDate() - env.KEKA_POLL_LOOKBACK_DAYS);

  const filter = `receivedDateTime ge ${lookbackDate.toISOString()} and from/emailAddress/address eq '${env.KEKA_SENDER_EMAIL}'`;
  const mailbox = encodeURIComponent(env.KEKA_MAILBOX!);

  const messagesResponse = await graphFetch<{ value: GraphMessage[] }>(
    `/users/${mailbox}/messages?$filter=${encodeURIComponent(filter)}&$select=id,subject,receivedDateTime,from,hasAttachments&$top=50`,
    token
  );

  const messages = messagesResponse.value ?? [];
  result.messagesFound = messages.length;

  for (const message of messages) {
    try {
      // Subject matching is a plain, configurable, case-insensitive
      // substring check — the real KEKA subject line is unconfirmed
      // (Decision 8/10), so this is deliberately not a regex or an assumed
      // fixed string. An unset KEKA_SUBJECT_PATTERN matches on sender alone.
      if (env.KEKA_SUBJECT_PATTERN && !message.subject?.toLowerCase().includes(env.KEKA_SUBJECT_PATTERN.toLowerCase())) {
        continue;
      }

      // P2-08 — previously: any existing TimesheetImport for this email,
      // regardless of status, was treated as "already processed" and
      // skipped forever — so a transient failure permanently and silently
      // dropped that day's Keka data. decideImportEligibility() now
      // distinguishes Succeeded/PartiallySucceeded (skip, correct as
      // before), Processing/Pending (skip — another attempt is already in
      // flight, never start a second one), and Failed (retry-eligible,
      // atomically claimed so two concurrent poll executions can never both
      // retry the same email — see that function's own comment).
      const eligibility = await decideImportEligibility(message.id);
      if (eligibility.action === "skip") {
        result.skippedAlreadyProcessed++;
        continue;
      }

      if (!message.hasAttachments) {
        result.skippedNoAttachment++;
        continue;
      }

      const attachmentsResponse = await graphFetch<{ value: GraphAttachment[] }>(
        `/users/${mailbox}/messages/${message.id}/attachments`,
        token
      );

      const attachment = (attachmentsResponse.value ?? []).find((a) =>
        a.name?.toLowerCase().includes(env.KEKA_ATTACHMENT_NAME!.toLowerCase())
      );

      // KNOWN GAP: Graph only returns `contentBytes` inline for attachments
      // under its own size threshold (historically ~3MB) via this
      // endpoint — a larger real KEKA file would need the `$value`
      // streaming endpoint instead, not yet implemented (real attachment
      // size is unverified — Stage 4 §7 open question).
      if (!attachment || !attachment.contentBytes) {
        result.skippedNoAttachment++;
        continue;
      }

      const bytes = Buffer.from(attachment.contentBytes, "base64");
      validateAttachment(attachment.name, bytes);
      const parsed = parseTimesheetWorkbook(bytes);

      // The TimesheetImport row is only created (inside
      // processTimesheetImport, via createImport) once these bytes are
      // already fully downloaded and parsed — a network/Graph failure
      // before this point leaves no trace at all, so the next poll cycle
      // naturally retries this same message (Stage 4 §15's idempotent-
      // retry design).
      const importResult = await processTimesheetImport(parsed.rows, {
        triggeredBy: "EmailPoll",
        emailMessageId: message.id,
        attachmentId: attachment.id,
        attachmentFilename: attachment.name,
        receivedAt: new Date(message.receivedDateTime),
        invalidRows: parsed.invalidRows,
        existingImportId: eligibility.action === "retryExisting" ? eligibility.existingImportId : null,
      });

      result.processed++;
      result.createdCount += importResult.createdCount;
      result.updatedCount += importResult.updatedCount;
      result.unchangedCount += importResult.unchangedCount;
      result.removedCount += importResult.removedCount;
      result.failedCount += importResult.failedCount;

      // Priority #6 Phase 3B — ONE summary notification per processed
      // email/import, after processTimesheetImport() has already fully
      // resolved and committed. Never inside that function, never per-row.
      // notify() is fire-and-forget and never throws (see
      // notification.service.ts's own contract), so this can never turn a
      // successful import into a poll-loop error.
      await notifyTimesheetImportOutcome(importResult, "Keka");
    } catch (err) {
      const messageText = err instanceof Error ? err.message : "Unknown error.";
      result.errors.push(`Message ${message.id}: ${messageText}`);

      // Priority #6 Phase 3B — this message failed somewhere in
      // parsing/validation/reconciliation. A TimesheetImport row may or may
      // not exist depending on exactly where it failed (processTimesheetImport
      // itself already finalizes a row as "Failed" before rethrowing, but
      // that id isn't available at this catch site) — entityId is
      // deliberately left null here rather than guessing, per the approved
      // design ("do NOT invent an entity ID").
      await notifyKekaImportFailedBeforeImportRow(`Message ${message.id}: ${messageText}`);
    }
  }

  return result;
}
